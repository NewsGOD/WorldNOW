import React from 'react';
import { Hash, TrendingUp } from 'lucide-react';

const topics = [
  { name: 'Climate Change', count: '2.3k articles', trend: 'up' },
  { name: 'Artificial Intelligence', count: '1.8k articles', trend: 'up' },
  { name: 'Economic Recovery', count: '1.5k articles', trend: 'stable' },
  { name: 'Space Exploration', count: '892 articles', trend: 'up' },
  { name: 'Renewable Energy', count: '743 articles', trend: 'up' },
  { name: 'Global Health', count: '654 articles', trend: 'down' },
  { name: 'Cybersecurity', count: '521 articles', trend: 'up' },
  { name: 'Social Media', count: '487 articles', trend: 'stable' },
];

export const PopularTopics: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Hash className="h-5 w-5 text-primary-600" />
        <h2 className="text-lg font-semibold text-gray-900">Popular Topics</h2>
      </div>
      
      <div className="space-y-3">
        {topics.map((topic, index) => (
          <div key={topic.name} className="flex items-center justify-between group cursor-pointer hover:bg-gray-50 p-2 rounded-md transition-colors">
            <div className="flex items-center space-x-3">
              <div className="text-sm font-medium text-gray-600 w-6">
                #{index + 1}
              </div>
              <div>
                <div className="text-sm font-medium text-gray-900 group-hover:text-primary-600">
                  {topic.name}
                </div>
                <div className="text-xs text-gray-500">
                  {topic.count}
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <TrendingUp 
                className={`h-4 w-4 ${
                  topic.trend === 'up' ? 'text-green-500' : 
                  topic.trend === 'down' ? 'text-red-500 rotate-180' : 
                  'text-gray-400'
                }`} 
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};