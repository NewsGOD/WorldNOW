import React from 'react';
import { X, Home, TrendingUp, Globe, Briefcase, Zap, Gamepad2, Heart, Atom, Newspaper, Users, Camera, Music } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCategory: string;
  onCategorySelect: (category: string) => void;
}

const categories = [
  { id: 'all', name: 'All News', icon: Home },
  { id: 'trending', name: 'Trending', icon: TrendingUp },
  { id: 'world', name: 'World', icon: Globe },
  { id: 'business', name: 'Business', icon: Briefcase },
  { id: 'technology', name: 'Technology', icon: Zap },
  { id: 'sports', name: 'Sports', icon: Gamepad2 },
  { id: 'health', name: 'Health', icon: Heart },
  { id: 'science', name: 'Science', icon: Atom },
  { id: 'environment', name: 'Environment', icon: Globe },
  { id: 'politics', name: 'Politics', icon: Users },
  { id: 'entertainment', name: 'Entertainment', icon: Camera },
  { id: 'lifestyle', name: 'Lifestyle', icon: Music },
  { id: 'opinion', name: 'Opinion', icon: Newspaper },
];

export const Sidebar: React.FC<SidebarProps> = ({ 
  isOpen, 
  onClose, 
  selectedCategory, 
  onCategorySelect 
}) => {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-50
        lg:relative lg:translate-x-0 lg:shadow-none lg:border-r lg:border-gray-200
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="flex items-center justify-between p-4 border-b border-gray-200 lg:hidden">
          <h2 className="text-lg font-semibold text-gray-900">Categories</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <nav className="p-4 h-full overflow-y-auto">
          <div className="space-y-2">
            {categories.map((category) => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => {
                    onCategorySelect(category.id);
                    onClose();
                  }}
                  className={`
                    w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors
                    ${selectedCategory === category.id
                      ? 'bg-primary-50 text-primary-700 border border-primary-200'
                      : 'text-gray-700 hover:bg-gray-100'
                    }
                  `}
                >
                  <Icon className="h-5 w-5" />
                  <span className="font-medium">{category.name}</span>
                </button>
              );
            })}
          </div>
        </nav>
      </div>
    </>
  );
};