import { NewsArticle } from '../types/news';

export const mockNewsData: NewsArticle[] = [
  {
    id: '1',
    title: 'Revolutionary AI Technology Transforms Healthcare Industry',
    description: 'New artificial intelligence breakthrough promises to revolutionize medical diagnosis and treatment, offering unprecedented accuracy in detecting diseases.',
    content: 'A groundbreaking AI system developed by researchers has achieved remarkable success in medical diagnosis, showing 95% accuracy in detecting various conditions. This technology could transform healthcare delivery worldwide.',
    url: 'https://example.com/ai-healthcare',
    urlToImage: 'https://images.pexels.com/photos/3825581/pexels-photo-3825581.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date().toISOString(),
    source: {
      id: 'tech-news',
      name: 'Tech News Daily'
    },
    author: 'Dr. Sarah Johnson',
    category: 'technology'
  },
  {
    id: '2',
    title: 'Global Climate Summit Reaches Historic Agreement',
    description: 'World leaders unite on ambitious climate action plan, setting new targets for carbon reduction and renewable energy adoption.',
    content: 'The international climate summit concluded with unprecedented cooperation among nations, establishing binding commitments for carbon neutrality by 2050.',
    url: 'https://example.com/climate-summit',
    urlToImage: 'https://images.pexels.com/photos/9324336/pexels-photo-9324336.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 3600000).toISOString(),
    source: {
      id: 'world-report',
      name: 'World Report'
    },
    author: 'Michael Chen',
    category: 'environment'
  },
  {
    id: '3',
    title: 'Stock Markets Surge on Economic Recovery Signs',
    description: 'Major indices hit record highs as investors respond positively to strong employment data and corporate earnings reports.',
    content: 'Financial markets experienced significant gains today, with the S&P 500 reaching new heights amid optimistic economic indicators and robust quarterly earnings.',
    url: 'https://example.com/market-surge',
    urlToImage: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 7200000).toISOString(),
    source: {
      id: 'financial-times',
      name: 'Financial Times'
    },
    author: 'Emma Rodriguez',
    category: 'business'
  },
  {
    id: '4',
    title: 'Space Mission Discovers Potential Signs of Life',
    description: 'NASA\'s latest Mars rover mission uncovers compelling evidence that could indicate past microbial life on the Red Planet.',
    content: 'The Perseverance rover has collected samples showing organic compounds and mineral formations that scientists believe could be biosignatures of ancient life.',
    url: 'https://example.com/mars-discovery',
    urlToImage: 'https://images.pexels.com/photos/586063/pexels-photo-586063.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 10800000).toISOString(),
    source: {
      id: 'space-news',
      name: 'Space News Network'
    },
    author: 'Dr. James Wilson',
    category: 'science'
  },
  {
    id: '5',
    title: 'Olympic Games Break Viewership Records',
    description: 'The latest Olympic Games achieve unprecedented global audience numbers, showcasing remarkable athletic performances.',
    content: 'With over 3 billion viewers worldwide, this year\'s Olympic Games have become the most-watched sporting event in history, featuring record-breaking performances.',
    url: 'https://example.com/olympics-records',
    urlToImage: 'https://images.pexels.com/photos/209977/pexels-photo-209977.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 14400000).toISOString(),
    source: {
      id: 'sports-central',
      name: 'Sports Central'
    },
    author: 'Lisa Thompson',
    category: 'sports'
  },
  {
    id: '6',
    title: 'Breakthrough in Renewable Energy Storage',
    description: 'Scientists develop new battery technology that could solve the intermittency problem of solar and wind power.',
    content: 'A revolutionary battery system promises to store renewable energy for weeks, potentially transforming the global energy landscape and accelerating the transition to clean power.',
    url: 'https://example.com/battery-breakthrough',
    urlToImage: 'https://images.pexels.com/photos/9800029/pexels-photo-9800029.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 18000000).toISOString(),
    source: {
      id: 'energy-today',
      name: 'Energy Today'
    },
    author: 'Dr. Alex Kumar',
    category: 'technology'
  },
  {
    id: '7',
    title: 'New Archaeological Discovery Rewrites History',
    description: 'Ancient civilization uncovered in South America challenges existing theories about early human migration patterns.',
    content: 'Archaeologists have discovered a previously unknown civilization that flourished 5,000 years ago, providing new insights into ancient human societies.',
    url: 'https://example.com/archaeology-discovery',
    urlToImage: 'https://images.pexels.com/photos/4321802/pexels-photo-4321802.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 21600000).toISOString(),
    source: {
      id: 'history-channel',
      name: 'History Channel News'
    },
    author: 'Prof. Maria Santos',
    category: 'science'
  },
  {
    id: '8',
    title: 'Global Food Security Initiative Launches',
    description: 'International coalition announces comprehensive plan to address hunger and improve agricultural sustainability worldwide.',
    content: 'A $50 billion initiative aims to eliminate hunger by 2030 through innovative farming techniques, improved distribution networks, and sustainable practices.',
    url: 'https://example.com/food-security',
    urlToImage: 'https://images.pexels.com/photos/1459339/pexels-photo-1459339.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 25200000).toISOString(),
    source: {
      id: 'global-news',
      name: 'Global News Network'
    },
    author: 'Robert Kim',
    category: 'world'
  },
  {
    id: '9',
    title: 'Major Political Reform Bill Passes Senate',
    description: 'Landmark legislation addressing voting rights and campaign finance reform receives bipartisan support.',
    content: 'After months of debate, the Senate has passed comprehensive political reform legislation that aims to strengthen democratic institutions and increase transparency.',
    url: 'https://example.com/political-reform',
    urlToImage: 'https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 28800000).toISOString(),
    source: {
      id: 'political-news',
      name: 'Political News Today'
    },
    author: 'Jennifer Walsh',
    category: 'politics'
  },
  {
    id: '10',
    title: 'Hollywood Blockbuster Breaks Box Office Records',
    description: 'Latest superhero film shatters opening weekend records, earning over $300 million globally.',
    content: 'The highly anticipated sequel has exceeded all expectations, becoming the highest-grossing opening weekend in cinema history.',
    url: 'https://example.com/box-office-record',
    urlToImage: 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 32400000).toISOString(),
    source: {
      id: 'entertainment-weekly',
      name: 'Entertainment Weekly'
    },
    author: 'Mark Stevens',
    category: 'entertainment'
  },
  {
    id: '11',
    title: 'New Study Reveals Benefits of Mediterranean Diet',
    description: 'Comprehensive research shows significant health improvements from following traditional Mediterranean eating patterns.',
    content: 'A 10-year study involving 50,000 participants demonstrates that the Mediterranean diet reduces risk of heart disease by 30% and improves cognitive function.',
    url: 'https://example.com/mediterranean-diet',
    urlToImage: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 36000000).toISOString(),
    source: {
      id: 'health-journal',
      name: 'Health Journal'
    },
    author: 'Dr. Amanda Foster',
    category: 'health'
  },
  {
    id: '12',
    title: 'Sustainable Fashion Movement Gains Momentum',
    description: 'Major fashion brands commit to eco-friendly practices as consumers demand more sustainable clothing options.',
    content: 'The fashion industry is undergoing a transformation as brands adopt circular economy principles and consumers prioritize sustainability over fast fashion.',
    url: 'https://example.com/sustainable-fashion',
    urlToImage: 'https://images.pexels.com/photos/6069112/pexels-photo-6069112.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 39600000).toISOString(),
    source: {
      id: 'lifestyle-magazine',
      name: 'Lifestyle Magazine'
    },
    author: 'Sophie Chen',
    category: 'lifestyle'
  },
  {
    id: '13',
    title: 'Editorial: The Future of Remote Work',
    description: 'As companies adapt to post-pandemic realities, we examine the long-term implications of remote work on society.',
    content: 'The shift to remote work has fundamentally changed how we think about employment, productivity, and work-life balance. This editorial explores the challenges and opportunities ahead.',
    url: 'https://example.com/remote-work-editorial',
    urlToImage: 'https://images.pexels.com/photos/4226140/pexels-photo-4226140.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 43200000).toISOString(),
    source: {
      id: 'opinion-times',
      name: 'Opinion Times'
    },
    author: 'Editorial Board',
    category: 'opinion'
  },
  {
    id: '14',
    title: 'Quantum Computing Milestone Achieved',
    description: 'Researchers demonstrate quantum supremacy in solving complex mathematical problems previously impossible for classical computers.',
    content: 'A team of quantum physicists has successfully demonstrated a quantum computer solving a problem that would take classical computers thousands of years to complete.',
    url: 'https://example.com/quantum-computing',
    urlToImage: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 46800000).toISOString(),
    source: {
      id: 'science-daily',
      name: 'Science Daily'
    },
    author: 'Dr. Richard Park',
    category: 'science'
  },
  {
    id: '15',
    title: 'International Trade Agreement Signed',
    description: 'Major economies finalize comprehensive trade deal aimed at reducing tariffs and promoting economic cooperation.',
    content: 'The landmark agreement between 15 nations is expected to boost global trade by $2 trillion over the next decade while creating millions of jobs.',
    url: 'https://example.com/trade-agreement',
    urlToImage: 'https://images.pexels.com/photos/6077368/pexels-photo-6077368.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date(Date.now() - 50400000).toISOString(),
    source: {
      id: 'world-business',
      name: 'World Business Report'
    },
    author: 'Carlos Martinez',
    category: 'business'
  }
];