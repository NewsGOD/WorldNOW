import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { NewsCard } from './components/NewsCard';
import { TrendingNews } from './components/TrendingNews';
import { WeatherWidget } from './components/WeatherWidget';
import { LoadingSpinner } from './components/LoadingSpinner';
import { NewsletterSignup } from './components/NewsletterSignup';
import { UsefulLinks } from './components/UsefulLinks';
import { LiveUpdates } from './components/LiveUpdates';
import { PopularTopics } from './components/PopularTopics';
import { MarketTicker } from './components/MarketTicker';
import { ErrorBoundary } from './components/ErrorBoundary';
import { NewsService } from './services/newsService';
import { mockNewsData } from './data/mockNews';
import { NewsArticle } from './types/news';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [useDatabase, setUseDatabase] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadNews();
  }, [selectedCategory, useDatabase]);

  useEffect(() => {
    // Check if Supabase is configured
    const checkSupabaseConfig = () => {
      const isConfigured = NewsService.isSupabaseConfigured();
      setUseDatabase(isConfigured);
    };

    checkSupabaseConfig();
  }, []);

  const loadNews = async () => {
    setLoading(true);
    setError(null);
    
    try {
      if (useDatabase) {
        // Try to load from database first
        const dbArticles = await NewsService.getAllNews(
          selectedCategory === 'all' ? undefined : selectedCategory
        );
        
        if (dbArticles.length > 0) {
          setArticles(dbArticles);
        } else {
          // Fallback to mock data if no database articles
          console.log('No database articles found, using mock data');
          setArticles(mockNewsData);
        }
      } else {
        // Use mock data when database is not configured
        await new Promise(resolve => setTimeout(resolve, 1000));
        setArticles(mockNewsData);
      }
    } catch (error) {
      console.error('Error loading news:', error);
      setError('Failed to load news articles');
      // Fallback to mock data on error
      setArticles(mockNewsData);
    } finally {
      setLoading(false);
    }
  };

  const filteredArticles = selectedCategory === 'all' || selectedCategory === 'trending'
    ? articles
    : articles.filter(article => article.category === selectedCategory);

  const featuredArticle = filteredArticles[0];
  const regularArticles = filteredArticles.slice(1);

  const categoryTitle = selectedCategory === 'all' ? 'Latest News' : 
                       selectedCategory === 'trending' ? 'Trending News' :
                       `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} News`;

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        <Helmet>
          <title>World Today - Breaking News & Updates</title>
          <meta name="description" content="Stay informed with World Today - your source for breaking news, trending stories, and updates from around the globe." />
          <meta name="keywords" content="news, breaking news, world news, politics, business, technology, sports, health, entertainment" />
          <meta property="og:title" content="World Today - Breaking News & Updates" />
          <meta property="og:description" content="Stay informed with World Today - your source for breaking news, trending stories, and updates from around the globe." />
          <meta property="og:type" content="website" />
          <meta property="og:url" content={window.location.href} />
          <meta name="twitter:card" content="summary_large_image" />
          <meta name="twitter:title" content="World Today - Breaking News & Updates" />
          <meta name="twitter:description" content="Stay informed with World Today - your source for breaking news, trending stories, and updates from around the globe." />
          <link rel="canonical" href={window.location.href} />
        </Helmet>
        
        <Header onMenuClick={() => setSidebarOpen(true)} />
        
        <div className="flex">
          <Sidebar
            isOpen={sidebarOpen}
            onClose={() => setSidebarOpen(false)}
            selectedCategory={selectedCategory}
            onCategorySelect={setSelectedCategory}
          />
          
          <main className="flex-1 lg:ml-0">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              {/* Database Status Banner */}
              {!useDatabase && (
                <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-yellow-800">Demo Mode</h3>
                      <p className="text-sm text-yellow-700">
                        Connect to Supabase to enable news management features. Currently showing mock data.
                      </p>
                    </div>
                    <button
                      onClick={() => window.open('https://supabase.com', '_blank')}
                      className="text-sm text-yellow-800 hover:text-yellow-900 underline"
                    >
                      Setup Database
                    </button>
                  </div>
                </div>
              )}

              {/* Error Message */}
              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-700">{error}</p>
                </div>
              )}

              {loading ? (
                <LoadingSpinner />
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                  {/* Main Content */}
                  <div className="lg:col-span-3 space-y-8">
                    {/* Market Ticker */}
                    <section>
                      <MarketTicker />
                    </section>

                    {/* Featured Article */}
                    {featuredArticle && (
                      <section>
                        <div className="flex items-center justify-between mb-6">
                          <h2 className="text-2xl font-bold text-gray-900">
                            {selectedCategory === 'all' ? 'Featured Story' : 
                             selectedCategory === 'trending' ? 'Trending Story' :
                             `Top ${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Story`}
                          </h2>
                          <div className="h-1 flex-1 bg-gradient-to-r from-primary-500 to-transparent ml-4 rounded"></div>
                        </div>
                        <NewsCard article={featuredArticle} featured />
                      </section>
                    )}

                    {/* Regular Articles */}
                    <section>
                      <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-bold text-gray-900">{categoryTitle}</h2>
                        <div className="text-sm text-gray-500">
                          {filteredArticles.length} articles
                        </div>
                      </div>
                      {regularArticles.length > 0 ? (
                        <div className="grid gap-6">
                          {regularArticles.map((article) => (
                            <NewsCard key={article.id} article={article} />
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <p className="text-gray-600">No articles found for this category.</p>
                          {useDatabase && (
                            <p className="text-sm text-gray-500 mt-2">
                              Try adding some articles through the admin panel or fetch them from NewsAPI.
                            </p>
                          )}
                        </div>
                      )}
                    </section>
                  </div>

                  {/* Sidebar Content */}
                  <div className="lg:col-span-1 space-y-6">
                    <LiveUpdates />
                    <TrendingNews articles={articles} />
                    <PopularTopics />
                    <WeatherWidget />
                    <NewsletterSignup />
                    <UsefulLinks />
                    
                    {/* Quick Stats */}
                    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Today's Stats</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Articles Published</span>
                          <span className="font-semibold text-gray-900">{articles.length}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Sources</span>
                          <span className="font-semibold text-gray-900">
                            {new Set(articles.map(a => a.source.name)).size}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Categories</span>
                          <span className="font-semibold text-gray-900">
                            {new Set(articles.map(a => a.category)).size}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Database</span>
                          <span className={`font-semibold ${useDatabase ? 'text-green-600' : 'text-yellow-600'}`}>
                            {useDatabase ? 'Connected' : 'Demo Mode'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default App;