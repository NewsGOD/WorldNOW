import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase environment variables not found. Running in demo mode.');
}

export const supabase = createClient(
  supabaseUrl || 'https://demo.supabase.co', 
  supabaseAnonKey || 'demo-key'
);

export type Database = {
  public: {
    Tables: {
      news_articles: {
        Row: {
          id: string;
          title: string;
          description: string | null;
          content: string | null;
          url: string | null;
          url_to_image: string | null;
          published_at: string;
          source_id: string | null;
          source_name: string | null;
          author: string | null;
          category: string;
          is_featured: boolean;
          is_trending: boolean;
          view_count: number;
          created_at: string;
          updated_at: string;
          created_by: string | null;
        };
        Insert: {
          id?: string;
          title: string;
          description?: string | null;
          content?: string | null;
          url?: string | null;
          url_to_image?: string | null;
          published_at?: string;
          source_id?: string | null;
          source_name?: string | null;
          author?: string | null;
          category?: string;
          is_featured?: boolean;
          is_trending?: boolean;
          view_count?: number;
          created_at?: string;
          updated_at?: string;
          created_by?: string | null;
        };
        Update: {
          id?: string;
          title?: string;
          description?: string | null;
          content?: string | null;
          url?: string | null;
          url_to_image?: string | null;
          published_at?: string;
          source_id?: string | null;
          source_name?: string | null;
          author?: string | null;
          category?: string;
          is_featured?: boolean;
          is_trending?: boolean;
          view_count?: number;
          created_at?: string;
          updated_at?: string;
          created_by?: string | null;
        };
      };
      news_sources: {
        Row: {
          id: string;
          name: string;
          url: string | null;
          api_key: string | null;
          is_active: boolean;
          last_fetched: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          url?: string | null;
          api_key?: string | null;
          is_active?: boolean;
          last_fetched?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          url?: string | null;
          api_key?: string | null;
          is_active?: boolean;
          last_fetched?: string | null;
          created_at?: string;
        };
      };
      news_categories: {
        Row: {
          id: string;
          name: string;
          slug: string;
          description: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          slug: string;
          description?: string | null;
          is_active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          slug?: string;
          description?: string | null;
          is_active?: boolean;
          created_at?: string;
        };
      };
    };
  };
};