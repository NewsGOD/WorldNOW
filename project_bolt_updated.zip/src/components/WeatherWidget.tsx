import React from 'react';
import { Cloud, Sun, CloudRain, Wind } from 'lucide-react';

export const WeatherWidget: React.FC = () => {
  return (
    <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-sm p-6 text-white">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Weather</h2>
        <Sun className="h-6 w-6" />
      </div>
      <div className="space-y-3">
        <div>
          <div className="text-3xl font-bold">22°C</div>
          <div className="text-blue-100">New York, NY</div>
        </div>
        <div className="flex items-center justify-between text-sm text-blue-100">
          <div className="flex items-center space-x-1">
            <Wind className="h-4 w-4" />
            <span>12 km/h</span>
          </div>
          <div>Partly Cloudy</div>
        </div>
        <div className="flex justify-between text-xs text-blue-100 pt-2 border-t border-blue-400">
          <div>High: 25°</div>
          <div>Low: 18°</div>
        </div>
      </div>
    </div>
  );
};