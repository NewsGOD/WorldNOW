import { supabase } from '../lib/supabase';
import { NewsArticle } from '../types/news';

export class NewsService {
  // Check if Supabase is properly configured
  static isSupabaseConfigured(): boolean {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    return !!(supabaseUrl && supabaseKey && supabaseUrl !== 'https://demo.supabase.co');
  }

  // Fetch all news articles
  static async getAllNews(category?: string, limit?: number): Promise<NewsArticle[]> {
    if (!this.isSupabaseConfigured()) {
      console.warn('Supabase not configured, returning empty array');
      return [];
    }

    try {
      let query = supabase
        .from('news_articles')
        .select('*')
        .order('published_at', { ascending: false });

      if (category && category !== 'all' && category !== 'trending') {
        query = query.eq('category', category);
      }

      if (limit) {
        query = query.limit(limit);
      }

      const { data, error } = await query;
      
      if (error) {
        console.error('Error fetching news:', error);
        return [];
      }

      return this.transformToNewsArticles(data || []);
    } catch (error) {
      console.error('Error in getAllNews:', error);
      return [];
    }
  }

  // Fetch trending news
  static async getTrendingNews(limit = 5): Promise<NewsArticle[]> {
    if (!this.isSupabaseConfigured()) {
      return [];
    }

    try {
      const { data, error } = await supabase
        .from('news_articles')
        .select('*')
        .or('is_trending.eq.true,view_count.gt.50')
        .order('view_count', { ascending: false })
        .limit(limit);

      if (error) {
        console.error('Error fetching trending news:', error);
        return [];
      }

      return this.transformToNewsArticles(data || []);
    } catch (error) {
      console.error('Error in getTrendingNews:', error);
      return [];
    }
  }

  // Fetch featured news
  static async getFeaturedNews(): Promise<NewsArticle | null> {
    if (!this.isSupabaseConfigured()) {
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('news_articles')
        .select('*')
        .eq('is_featured', true)
        .order('published_at', { ascending: false })
        .limit(1);

      if (error) {
        console.error('Error fetching featured news:', error);
        return null;
      }

      if (!data || data.length === 0) {
        return null;
      }

      return this.transformToNewsArticle(data[0]);
    } catch (error) {
      console.error('Error in getFeaturedNews:', error);
      return null;
    }
  }

  // Add new news article
  static async addNews(article: Omit<NewsArticle, 'id'>): Promise<NewsArticle> {
    if (!this.isSupabaseConfigured()) {
      throw new Error('Supabase not configured');
    }

    try {
      const { data: user } = await supabase.auth.getUser();
      
      const insertData = {
        title: article.title,
        description: article.description || null,
        content: article.content || null,
        url: article.url || null,
        url_to_image: article.urlToImage || null,
        published_at: article.publishedAt || new Date().toISOString(),
        source_id: article.source?.id || null,
        source_name: article.source?.name || null,
        author: article.author || null,
        category: article.category || 'general',
        is_featured: false,
        is_trending: false,
        view_count: 0,
        created_by: user.user?.id || null
      };

      const { data, error } = await supabase
        .from('news_articles')
        .insert(insertData)
        .select()
        .single();

      if (error) {
        console.error('Error adding news:', error);
        throw error;
      }

      return this.transformToNewsArticle(data);
    } catch (error) {
      console.error('Error in addNews:', error);
      throw error;
    }
  }

  // Update news article
  static async updateNews(id: string, updates: Partial<NewsArticle>): Promise<NewsArticle> {
    if (!this.isSupabaseConfigured()) {
      throw new Error('Supabase not configured');
    }

    try {
      const updateData: any = {};
      
      if (updates.title !== undefined) updateData.title = updates.title;
      if (updates.description !== undefined) updateData.description = updates.description;
      if (updates.content !== undefined) updateData.content = updates.content;
      if (updates.url !== undefined) updateData.url = updates.url;
      if (updates.urlToImage !== undefined) updateData.url_to_image = updates.urlToImage;
      if (updates.author !== undefined) updateData.author = updates.author;
      if (updates.category !== undefined) updateData.category = updates.category;

      const { data, error } = await supabase
        .from('news_articles')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Error updating news:', error);
        throw error;
      }

      return this.transformToNewsArticle(data);
    } catch (error) {
      console.error('Error in updateNews:', error);
      throw error;
    }
  }

  // Delete news article
  static async deleteNews(id: string): Promise<void> {
    if (!this.isSupabaseConfigured()) {
      throw new Error('Supabase not configured');
    }

    try {
      const { error } = await supabase
        .from('news_articles')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting news:', error);
        throw error;
      }
    } catch (error) {
      console.error('Error in deleteNews:', error);
      throw error;
    }
  }

  // Increment view count
  static async incrementViewCount(id: string): Promise<void> {
    if (!this.isSupabaseConfigured()) {
      return;
    }

    try {
      const { error } = await supabase.rpc('increment_view_count', { article_id: id });
      
      if (error) {
        console.error('Error incrementing view count:', error);
      }
    } catch (error) {
      console.error('Error in incrementViewCount:', error);
    }
  }

  // Fetch news from external API (NewsAPI)
  static async fetchFromNewsAPI(apiKey: string, category?: string): Promise<void> {
    if (!this.isSupabaseConfigured()) {
      throw new Error('Supabase not configured');
    }

    if (!apiKey || apiKey.trim() === '') {
      throw new Error('API key is required');
    }

    try {
      const categoryParam = category && category !== 'general' ? `&category=${category}` : '';
      const url = `https://newsapi.org/v2/top-headlines?country=us${categoryParam}&pageSize=20&apiKey=${apiKey}`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`NewsAPI request failed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();

      if (data.status !== 'ok') {
        throw new Error(data.message || 'NewsAPI returned an error');
      }

      if (!data.articles || data.articles.length === 0) {
        throw new Error('No articles found');
      }

      let successCount = 0;
      let errorCount = 0;

      for (const apiArticle of data.articles) {
        try {
          // Skip articles with missing required fields
          if (!apiArticle.title || apiArticle.title === '[Removed]') {
            continue;
          }

          const article: Omit<NewsArticle, 'id'> = {
            title: apiArticle.title,
            description: apiArticle.description || '',
            content: apiArticle.content || '',
            url: apiArticle.url || '',
            urlToImage: apiArticle.urlToImage || '',
            publishedAt: apiArticle.publishedAt || new Date().toISOString(),
            source: {
              id: apiArticle.source?.id || 'newsapi',
              name: apiArticle.source?.name || 'NewsAPI'
            },
            author: apiArticle.author || null,
            category: category || 'general'
          };

          await this.addNews(article);
          successCount++;
        } catch (error) {
          console.error('Error saving individual article:', error);
          errorCount++;
        }
      }

      if (successCount === 0) {
        throw new Error('No articles could be saved');
      }

      console.log(`Successfully imported ${successCount} articles, ${errorCount} failed`);
    } catch (error) {
      console.error('Error fetching from NewsAPI:', error);
      throw error;
    }
  }

  // Transform database row to NewsArticle
  private static transformToNewsArticle(data: any): NewsArticle {
    return {
      id: data.id,
      title: data.title || '',
      description: data.description || '',
      content: data.content || '',
      url: data.url || '',
      urlToImage: data.url_to_image || '',
      publishedAt: data.published_at || new Date().toISOString(),
      source: {
        id: data.source_id || '',
        name: data.source_name || 'Unknown Source'
      },
      author: data.author || null,
      category: data.category || 'general'
    };
  }

  // Transform database rows to NewsArticles
  private static transformToNewsArticles(data: any[]): NewsArticle[] {
    return data.map(item => this.transformToNewsArticle(item));
  }
}