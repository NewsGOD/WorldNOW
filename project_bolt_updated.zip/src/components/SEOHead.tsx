import React from 'react';
import { Helmet } from 'react-helmet-async';
import { NewsArticle } from '../types/news';

interface SEOHeadProps {
  title?: string;
  description?: string;
  article?: NewsArticle;
  category?: string;
}

export const SEOHead: React.FC<SEOHeadProps> = ({ 
  title, 
  description, 
  article, 
  category 
}) => {
  const defaultTitle = 'World Today - Breaking News & Updates';
  const defaultDescription = 'Stay informed with World Today - your source for breaking news, trending stories, and updates from around the globe.';
  
  const pageTitle = title || (article ? article.title : defaultTitle);
  const pageDescription = description || (article ? article.description : defaultDescription);
  const canonicalUrl = window.location.href;

  return (
    <Helmet>
      <title>{pageTitle}</title>
      <meta name="description" content={pageDescription} />
      
      {/* Open Graph */}
      <meta property="og:title" content={pageTitle} />
      <meta property="og:description" content={pageDescription} />
      <meta property="og:type" content={article ? 'article' : 'website'} />
      <meta property="og:url" content={canonicalUrl} />
      {article?.urlToImage && (
        <meta property="og:image" content={article.urlToImage} />
      )}
      
      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={pageTitle} />
      <meta name="twitter:description" content={pageDescription} />
      {article?.urlToImage && (
        <meta name="twitter:image" content={article.urlToImage} />
      )}
      
      {/* Article specific meta */}
      {article && (
        <>
          <meta property="article:published_time" content={article.publishedAt} />
          <meta property="article:author" content={article.author || 'World Today'} />
          <meta property="article:section" content={article.category} />
        </>
      )}
      
      {/* Category specific meta */}
      {category && (
        <meta name="keywords" content={`${category} news, ${category} updates, breaking ${category} news`} />
      )}
      
      <link rel="canonical" href={canonicalUrl} />
    </Helmet>
  );
};