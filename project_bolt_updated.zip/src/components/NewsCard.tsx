import React from 'react';
import { Clock, ExternalLink, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { NewsArticle } from '../types/news';

interface NewsCardProps {
  article: NewsArticle;
  featured?: boolean;
}

export const NewsCard: React.FC<NewsCardProps> = ({ article, featured = false }) => {
  const timeAgo = formatDistanceToNow(new Date(article.publishedAt), { addSuffix: true });

  if (featured) {
    return (
      <article className="group relative bg-white rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-200 animate-fade-in">
        <div className="aspect-video relative overflow-hidden">
          <img
            src={article.urlToImage}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <div className="flex items-center space-x-2 mb-2">
              <span className="bg-primary-600 text-white px-2 py-1 rounded-full text-xs font-medium">
                {article.source.name}
              </span>
              <span className="bg-black/30 text-white px-2 py-1 rounded-full text-xs backdrop-blur-sm">
                {article.category.toUpperCase()}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white mb-2 line-clamp-2">
              {article.title}
            </h2>
            <p className="text-gray-200 text-sm line-clamp-2">
              {article.description}
            </p>
          </div>
        </div>
        <div className="p-6">
          <div className="flex items-center justify-between text-sm text-gray-500">
            <div className="flex items-center space-x-4">
              {article.author && (
                <div className="flex items-center space-x-1">
                  <User className="h-4 w-4" />
                  <span>{article.author}</span>
                </div>
              )}
              <div className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span>{timeAgo}</span>
              </div>
            </div>
            <button className="flex items-center space-x-1 text-primary-600 hover:text-primary-700 transition-colors">
              <span>Read more</span>
              <ExternalLink className="h-4 w-4" />
            </button>
          </div>
        </div>
      </article>
    );
  }

  return (
    <article className="group bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden border border-gray-200 animate-slide-up">
      <div className="flex">
        <div className="flex-shrink-0 w-32 h-24 relative overflow-hidden">
          <img
            src={article.urlToImage}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        <div className="flex-1 p-4">
          <div className="flex items-center space-x-2 mb-2">
            <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs font-medium">
              {article.source.name}
            </span>
            <span className="text-xs text-gray-500 uppercase tracking-wide">
              {article.category}
            </span>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-primary-600 transition-colors">
            {article.title}
          </h3>
          <p className="text-sm text-gray-600 line-clamp-2 mb-2">
            {article.description}
          </p>
          <div className="flex items-center justify-between text-xs text-gray-500">
            <div className="flex items-center space-x-1">
              <Clock className="h-3 w-3" />
              <span>{timeAgo}</span>
            </div>
            {article.author && (
              <div className="flex items-center space-x-1">
                <User className="h-3 w-3" />
                <span>{article.author}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </article>
  );
};