import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Save, X, Upload, RefreshCw, AlertCircle } from 'lucide-react';
import { NewsService } from '../services/newsService';
import { NewsArticle } from '../types/news';

interface AdminPanelProps {
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingArticle, setEditingArticle] = useState<NewsArticle | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [fetchingNews, setFetchingNews] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    content: '',
    url: '',
    urlToImage: '',
    author: '',
    category: 'general',
    source: { id: 'manual', name: 'Manual Entry' }
  });

  const categories = [
    'general', 'technology', 'business', 'sports', 'health', 
    'science', 'entertainment', 'politics', 'world', 'environment',
    'lifestyle', 'opinion'
  ];

  useEffect(() => {
    loadArticles();
  }, []);

  const showError = (message: string) => {
    setError(message);
    setTimeout(() => setError(null), 5000);
  };

  const showSuccess = (message: string) => {
    setSuccess(message);
    setTimeout(() => setSuccess(null), 3000);
  };

  const loadArticles = async () => {
    setLoading(true);
    setError(null);
    
    try {
      if (!NewsService.isSupabaseConfigured()) {
        showError('Supabase is not configured. Please connect to your database first.');
        setArticles([]);
        return;
      }

      const data = await NewsService.getAllNews();
      setArticles(data);
    } catch (error) {
      console.error('Error loading articles:', error);
      showError('Failed to load articles. Please try again.');
      setArticles([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!formData.title.trim()) {
      showError('Title is required');
      return;
    }

    try {
      const articleData = {
        ...formData,
        publishedAt: new Date().toISOString()
      } as Omit<NewsArticle, 'id'>;

      if (editingArticle) {
        await NewsService.updateNews(editingArticle.id, articleData);
        showSuccess('Article updated successfully!');
      } else {
        await NewsService.addNews(articleData);
        showSuccess('Article added successfully!');
      }
      
      resetForm();
      loadArticles();
    } catch (error: any) {
      console.error('Error saving article:', error);
      showError(error.message || 'Failed to save article. Please try again.');
    }
  };

  const handleEdit = (article: NewsArticle) => {
    setEditingArticle(article);
    setFormData({
      title: article.title,
      description: article.description,
      content: article.content,
      url: article.url,
      urlToImage: article.urlToImage,
      author: article.author || '',
      category: article.category,
      source: article.source
    });
    setShowAddForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this article?')) {
      return;
    }

    try {
      await NewsService.deleteNews(id);
      showSuccess('Article deleted successfully!');
      loadArticles();
    } catch (error: any) {
      console.error('Error deleting article:', error);
      showError(error.message || 'Failed to delete article. Please try again.');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      content: '',
      url: '',
      urlToImage: '',
      author: '',
      category: 'general',
      source: { id: 'manual', name: 'Manual Entry' }
    });
    setEditingArticle(null);
    setShowAddForm(false);
  };

  const fetchNewsFromAPI = async () => {
    if (!apiKey.trim()) {
      showError('Please enter your NewsAPI key');
      return;
    }

    if (!NewsService.isSupabaseConfigured()) {
      showError('Supabase is not configured. Please connect to your database first.');
      return;
    }

    setFetchingNews(true);
    setError(null);
    
    try {
      await NewsService.fetchFromNewsAPI(apiKey);
      showSuccess('News articles fetched and saved successfully!');
      loadArticles();
    } catch (error: any) {
      console.error('Error fetching news:', error);
      showError(error.message || 'Failed to fetch news. Please check your API key and try again.');
    } finally {
      setFetchingNews(false);
    }
  };

  if (!NewsService.isSupabaseConfigured()) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">Database Required</h2>
            <button
              onClick={onClose}
              className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="flex items-start space-x-3 mb-4">
            <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
            <div>
              <p className="text-gray-700 mb-2">
                The admin panel requires a Supabase database connection to manage news articles.
              </p>
              <p className="text-sm text-gray-600">
                Please click "Connect to Supabase" in the top right corner to set up your database first.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-full px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl h-full max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">News Admin Panel</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto h-full">
          {/* Error/Success Messages */}
          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-2">
              <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {success && (
            <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-green-700">{success}</p>
            </div>
          )}

          {/* API Integration Section */}
          <div className="mb-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="text-lg font-semibold text-blue-900 mb-4">Fetch News from API</h3>
            <div className="flex space-x-4">
              <input
                type="text"
                placeholder="Enter NewsAPI key (get from newsapi.org)"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={fetchNewsFromAPI}
                disabled={fetchingNews}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
              >
                {fetchingNews ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <Upload className="h-4 w-4" />
                )}
                <span>{fetchingNews ? 'Fetching...' : 'Fetch News'}</span>
              </button>
            </div>
            <p className="text-xs text-blue-700 mt-2">
              Get your free API key from <a href="https://newsapi.org" target="_blank" rel="noopener noreferrer" className="underline">newsapi.org</a>
            </p>
          </div>

          {/* Add/Edit Form */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                {editingArticle ? 'Edit Article' : 'Add New Article'}
              </h3>
              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 flex items-center space-x-2"
              >
                <Plus className="h-4 w-4" />
                <span>Add Article</span>
              </button>
            </div>

            {showAddForm && (
              <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-gray-50 rounded-lg">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                    <input
                      type="text"
                      required
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    >
                      {categories.map(cat => (
                        <option key={cat} value={cat}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Content</label>
                  <textarea
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    rows={5}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">URL</label>
                    <input
                      type="url"
                      value={formData.url}
                      onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Image URL</label>
                    <input
                      type="url"
                      value={formData.urlToImage}
                      onChange={(e) => setFormData({ ...formData, urlToImage: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Author</label>
                  <input
                    type="text"
                    value={formData.author}
                    onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                  />
                </div>

                <div className="flex space-x-4">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center space-x-2"
                  >
                    <Save className="h-4 w-4" />
                    <span>{editingArticle ? 'Update' : 'Save'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Articles List */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Manage Articles ({articles.length})
            </h3>
            {loading ? (
              <div className="text-center py-8">
                <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400 mb-2" />
                <p className="text-gray-600">Loading articles...</p>
              </div>
            ) : articles.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-600 mb-4">No articles found.</p>
                <p className="text-sm text-gray-500">
                  Add articles manually or fetch them from NewsAPI to get started.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {articles.map((article) => (
                  <div key={article.id} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900 mb-2">{article.title}</h4>
                        <p className="text-sm text-gray-600 mb-2 line-clamp-2">{article.description}</p>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span className="bg-gray-100 px-2 py-1 rounded">
                            {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
                          </span>
                          <span>Author: {article.author || 'Unknown'}</span>
                          <span>Source: {article.source.name}</span>
                          <span>{new Date(article.publishedAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <button
                          onClick={() => handleEdit(article)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                          title="Edit article"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(article.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-md transition-colors"
                          title="Delete article"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};