/*
  # Add RPC Functions for News Management

  1. Functions
    - increment_view_count: Increment article view count
    - get_trending_articles: Get articles with high view counts
    - get_featured_articles: Get featured articles
*/

-- Function to increment view count
CREATE OR REPLACE FUNCTION increment_view_count(article_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE news_articles 
  SET view_count = view_count + 1 
  WHERE id = article_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get trending articles
CREATE OR REPLACE FUNCTION get_trending_articles(limit_count integer DEFAULT 10)
RETURNS TABLE (
  id uuid,
  title text,
  description text,
  content text,
  url text,
  url_to_image text,
  published_at timestamptz,
  source_id text,
  source_name text,
  author text,
  category text,
  is_featured boolean,
  is_trending boolean,
  view_count integer,
  created_at timestamptz,
  updated_at timestamptz,
  created_by uuid
) AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM news_articles
  WHERE news_articles.is_trending = true OR news_articles.view_count > 100
  ORDER BY news_articles.view_count DESC, news_articles.published_at DESC
  LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get featured articles
CREATE OR REPLACE FUNCTION get_featured_articles(limit_count integer DEFAULT 5)
RETURNS TABLE (
  id uuid,
  title text,
  description text,
  content text,
  url text,
  url_to_image text,
  published_at timestamptz,
  source_id text,
  source_name text,
  author text,
  category text,
  is_featured boolean,
  is_trending boolean,
  view_count integer,
  created_at timestamptz,
  updated_at timestamptz,
  created_by uuid
) AS $$
BEGIN
  RETURN QUERY
  SELECT * FROM news_articles
  WHERE news_articles.is_featured = true
  ORDER BY news_articles.published_at DESC
  LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;