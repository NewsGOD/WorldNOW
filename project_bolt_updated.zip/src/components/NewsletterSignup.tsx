import React, { useState } from 'react';
import { Mail, CheckCircle } from 'lucide-react';

export const NewsletterSignup: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg shadow-sm p-6 text-white">
      <div className="flex items-center space-x-2 mb-4">
        <Mail className="h-5 w-5" />
        <h2 className="text-lg font-semibold">Stay Updated</h2>
      </div>
      
      {subscribed ? (
        <div className="flex items-center space-x-2 text-green-200">
          <CheckCircle className="h-5 w-5" />
          <span>Thanks for subscribing!</span>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-3">
          <p className="text-sm text-blue-100">
            Get daily news digest delivered to your inbox
          </p>
          <div className="flex space-x-2">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              className="flex-1 px-3 py-2 rounded-md text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-white"
              required
            />
            <button
              type="submit"
              className="px-4 py-2 bg-white text-primary-600 rounded-md text-sm font-medium hover:bg-gray-100 transition-colors"
            >
              Subscribe
            </button>
          </div>
        </form>
      )}
    </div>
  );
};