/*
  # News Management System Database Schema

  1. New Tables
    - `news_articles`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `content` (text)
      - `url` (text)
      - `url_to_image` (text)
      - `published_at` (timestamptz)
      - `source_id` (text)
      - `source_name` (text)
      - `author` (text)
      - `category` (text)
      - `is_featured` (boolean)
      - `is_trending` (boolean)
      - `view_count` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `created_by` (uuid, foreign key to auth.users)

    - `news_sources`
      - `id` (uuid, primary key)
      - `name` (text)
      - `url` (text)
      - `api_key` (text, encrypted)
      - `is_active` (boolean)
      - `last_fetched` (timestamptz)
      - `created_at` (timestamptz)

    - `news_categories`
      - `id` (uuid, primary key)
      - `name` (text)
      - `slug` (text)
      - `description` (text)
      - `is_active` (boolean)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage news
    - Add policies for public read access
*/

-- Create news_articles table
CREATE TABLE IF NOT EXISTS news_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  content text,
  url text,
  url_to_image text,
  published_at timestamptz DEFAULT now(),
  source_id text,
  source_name text,
  author text,
  category text DEFAULT 'general',
  is_featured boolean DEFAULT false,
  is_trending boolean DEFAULT false,
  view_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id)
);

-- Create news_sources table
CREATE TABLE IF NOT EXISTS news_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  url text,
  api_key text,
  is_active boolean DEFAULT true,
  last_fetched timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create news_categories table
CREATE TABLE IF NOT EXISTS news_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE news_articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE news_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE news_categories ENABLE ROW LEVEL SECURITY;

-- Policies for news_articles
CREATE POLICY "Anyone can read news articles"
  ON news_articles
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert news articles"
  ON news_articles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own news articles"
  ON news_articles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can delete their own news articles"
  ON news_articles
  FOR DELETE
  TO authenticated
  USING (auth.uid() = created_by);

-- Policies for news_sources
CREATE POLICY "Anyone can read news sources"
  ON news_sources
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can manage news sources"
  ON news_sources
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for news_categories
CREATE POLICY "Anyone can read news categories"
  ON news_categories
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can manage news categories"
  ON news_categories
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Insert default categories
INSERT INTO news_categories (name, slug, description) VALUES
  ('General', 'general', 'General news and updates'),
  ('Technology', 'technology', 'Technology and innovation news'),
  ('Business', 'business', 'Business and finance news'),
  ('Sports', 'sports', 'Sports news and updates'),
  ('Health', 'health', 'Health and medical news'),
  ('Science', 'science', 'Science and research news'),
  ('Entertainment', 'entertainment', 'Entertainment and celebrity news'),
  ('Politics', 'politics', 'Political news and government updates'),
  ('World', 'world', 'International news'),
  ('Environment', 'environment', 'Environmental and climate news'),
  ('Lifestyle', 'lifestyle', 'Lifestyle and culture news'),
  ('Opinion', 'opinion', 'Opinion pieces and editorials')
ON CONFLICT (slug) DO NOTHING;

-- Insert default news sources
INSERT INTO news_sources (name, url, is_active) VALUES
  ('NewsAPI', 'https://newsapi.org', true),
  ('RSS Feeds', 'https://rss-feeds.com', true),
  ('Manual Entry', 'manual', true)
ON CONFLICT DO NOTHING;

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_news_articles_updated_at
  BEFORE UPDATE ON news_articles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();