import React, { useState, useEffect } from 'react';
import { Radio, Clock } from 'lucide-react';

interface LiveUpdate {
  id: string;
  text: string;
  time: string;
  source: string;
}

const mockLiveUpdates: LiveUpdate[] = [
  {
    id: '1',
    text: 'Breaking: Major tech company announces quarterly earnings beat expectations',
    time: '2 min ago',
    source: 'Financial News'
  },
  {
    id: '2',
    text: 'Weather Alert: Severe thunderstorm warning issued for northeastern regions',
    time: '8 min ago',
    source: 'Weather Service'
  },
  {
    id: '3',
    text: 'Sports Update: Championship finals set for this weekend',
    time: '15 min ago',
    source: 'Sports Network'
  },
  {
    id: '4',
    text: 'Market Update: Stock indices showing positive momentum in early trading',
    time: '23 min ago',
    source: 'Market Watch'
  },
  {
    id: '5',
    text: 'International: Peace talks scheduled between neighboring countries',
    time: '31 min ago',
    source: 'World News'
  }
];

export const LiveUpdates: React.FC = () => {
  const [updates, setUpdates] = useState<LiveUpdate[]>(mockLiveUpdates);
  const [isLive, setIsLive] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate new updates
      const newUpdate: LiveUpdate = {
        id: Date.now().toString(),
        text: 'New development: Latest update from our newsroom',
        time: 'Just now',
        source: 'Live Desk'
      };
      
      setUpdates(prev => [newUpdate, ...prev.slice(0, 4)]);
    }, 30000); // New update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Radio className="h-5 w-5 text-red-500" />
            {isLive && (
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            )}
          </div>
          <h2 className="text-lg font-semibold text-gray-900">Live Updates</h2>
        </div>
        <span className="text-xs text-red-500 font-medium bg-red-50 px-2 py-1 rounded-full">
          LIVE
        </span>
      </div>
      
      <div className="space-y-4 max-h-80 overflow-y-auto">
        {updates.map((update, index) => (
          <div 
            key={update.id} 
            className={`border-l-2 pl-4 pb-4 ${
              index === 0 ? 'border-red-500' : 'border-gray-200'
            } ${index === 0 ? 'animate-fade-in' : ''}`}
          >
            <div className="flex items-start justify-between">
              <p className="text-sm text-gray-900 leading-relaxed">
                {update.text}
              </p>
            </div>
            <div className="flex items-center space-x-2 mt-2 text-xs text-gray-500">
              <Clock className="h-3 w-3" />
              <span>{update.time}</span>
              <span>•</span>
              <span>{update.source}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};