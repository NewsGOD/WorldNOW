import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MarketData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
}

const mockMarketData: MarketData[] = [
  { symbol: 'AAPL', name: 'Apple Inc.', price: 175.43, change: 2.15, changePercent: 1.24 },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', price: 2847.63, change: -12.45, changePercent: -0.43 },
  { symbol: 'MSFT', name: 'Microsoft Corp.', price: 338.11, change: 5.67, changePercent: 1.71 },
  { symbol: 'TSLA', name: 'Tesla Inc.', price: 248.50, change: -3.22, changePercent: -1.28 },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', price: 3247.15, change: 18.75, changePercent: 0.58 },
];

export const MarketTicker: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % mockMarketData.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const currentStock = mockMarketData[currentIndex];

  return (
    <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-lg shadow-sm p-4 text-white">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-300">Market Ticker</h3>
        <div className="flex space-x-1">
          {mockMarketData.map((_, index) => (
            <div
              key={index}
              className={`w-1.5 h-1.5 rounded-full transition-colors ${
                index === currentIndex ? 'bg-white' : 'bg-gray-600'
              }`}
            />
          ))}
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-bold text-lg">{currentStock.symbol}</div>
            <div className="text-xs text-gray-400">{currentStock.name}</div>
          </div>
          <div className="text-right">
            <div className="font-bold text-lg">${currentStock.price.toFixed(2)}</div>
            <div className={`flex items-center space-x-1 text-sm ${
              currentStock.change >= 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {currentStock.change >= 0 ? (
                <TrendingUp className="h-3 w-3" />
              ) : (
                <TrendingDown className="h-3 w-3" />
              )}
              <span>
                {currentStock.change >= 0 ? '+' : ''}{currentStock.change.toFixed(2)} 
                ({currentStock.changePercent >= 0 ? '+' : ''}{currentStock.changePercent.toFixed(2)}%)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};