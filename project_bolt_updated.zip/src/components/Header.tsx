import React, { useState, useEffect } from 'react';
import { Globe, Menu, Search, Bell, Settings, LogIn, LogOut, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { NewsService } from '../services/newsService';
import { AdminPanel } from './AdminPanel';

interface HeaderProps {
  onMenuClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  const [user, setUser] = useState<any>(null);
  const [showAdmin, setShowAdmin] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    // Only try to get user if Supabase is configured
    if (NewsService.isSupabaseConfigured()) {
      // Get initial user
      supabase.auth.getUser().then(({ data: { user } }) => {
        setUser(user);
      });

      // Listen for auth changes
      const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
        setUser(session?.user ?? null);
        if (event === 'SIGNED_IN') {
          setAuthError(null);
        }
      });

      return () => subscription.unsubscribe();
    }
  }, []);

  const handleSignIn = async () => {
    if (!NewsService.isSupabaseConfigured()) {
      setAuthError('Please connect to Supabase first');
      return;
    }

    setAuthLoading(true);
    setAuthError(null);

    try {
      // Try to sign in first
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: 'admin@worldtoday.com',
        password: 'admin123'
      });
      
      if (signInError) {
        // If user doesn't exist, create account
        const { error: signUpError } = await supabase.auth.signUp({
          email: 'admin@worldtoday.com',
          password: 'admin123'
        });
        
        if (signUpError) {
          console.error('Error signing up:', signUpError);
          setAuthError('Failed to create admin account');
        }
      }
    } catch (error) {
      console.error('Authentication error:', error);
      setAuthError('Authentication failed');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    if (!NewsService.isSupabaseConfigured()) {
      return;
    }

    try {
      await supabase.auth.signOut();
      setAuthError(null);
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <>
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo and Brand */}
            <div className="flex items-center space-x-4">
              <button
                onClick={onMenuClick}
                className="lg:hidden p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-colors"
              >
                <Menu className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-2">
                <div className="bg-primary-600 p-2 rounded-lg">
                  <Globe className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">World Today</h1>
                  <p className="text-xs text-gray-500 hidden sm:block">Breaking News & Updates</p>
                </div>
              </div>
            </div>

            {/* Search Bar */}
            <div className="hidden md:flex flex-1 max-w-lg mx-8">
              <div className="relative w-full">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search news..."
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-4">
              <button className="md:hidden p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-colors">
                <Search className="h-5 w-5" />
              </button>
              <button className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-colors relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 block h-2 w-2 rounded-full bg-red-400"></span>
              </button>
              
              {NewsService.isSupabaseConfigured() ? (
                user ? (
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setShowAdmin(true)}
                      className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-colors"
                      title="Admin Panel"
                    >
                      <Settings className="h-5 w-5" />
                    </button>
                    <button
                      onClick={handleSignOut}
                      className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-colors"
                      title="Sign Out"
                    >
                      <LogOut className="h-5 w-5" />
                    </button>
                    <div className="text-xs text-green-600 font-medium">
                      Admin
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={handleSignIn}
                      disabled={authLoading}
                      className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 transition-colors disabled:opacity-50"
                      title="Admin Sign In"
                    >
                      <LogIn className="h-5 w-5" />
                    </button>
                    {authLoading && (
                      <div className="text-xs text-gray-500">Signing in...</div>
                    )}
                  </div>
                )
              ) : (
                <div className="flex items-center space-x-2">
                  <AlertCircle className="h-5 w-5 text-yellow-500" />
                  <span className="text-xs text-yellow-600 hidden sm:block">DB Not Connected</span>
                </div>
              )}
              
              <div className="hidden sm:block text-sm text-gray-500">
                {new Date().toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </div>
          </div>
          
          {/* Auth Error Message */}
          {authError && (
            <div className="px-4 py-2 bg-red-50 border-t border-red-200">
              <div className="flex items-center space-x-2">
                <AlertCircle className="h-4 w-4 text-red-500" />
                <span className="text-sm text-red-700">{authError}</span>
              </div>
            </div>
          )}
        </div>
      </header>

      {showAdmin && <AdminPanel onClose={() => setShowAdmin(false)} />}
    </>
  );
};