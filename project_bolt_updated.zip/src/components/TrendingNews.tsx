import React from 'react';
import { TrendingUp, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { NewsArticle } from '../types/news';

interface TrendingNewsProps {
  articles: NewsArticle[];
}

export const TrendingNews: React.FC<TrendingNewsProps> = ({ articles }) => {
  const trendingArticles = articles.slice(0, 5);

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-4">
        <TrendingUp className="h-5 w-5 text-red-500" />
        <h2 className="text-lg font-semibold text-gray-900">Trending Now</h2>
      </div>
      <div className="space-y-4">
        {trendingArticles.map((article, index) => (
          <div key={article.id} className="flex items-start space-x-3 group cursor-pointer">
            <div className="flex-shrink-0 w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
              {index + 1}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-medium text-gray-900 line-clamp-2 group-hover:text-primary-600 transition-colors">
                {article.title}
              </h3>
              <div className="flex items-center space-x-2 mt-1 text-xs text-gray-500">
                <span>{article.source.name}</span>
                <span>•</span>
                <div className="flex items-center space-x-1">
                  <Clock className="h-3 w-3" />
                  <span>{formatDistanceToNow(new Date(article.publishedAt), { addSuffix: true })}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};