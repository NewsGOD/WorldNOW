import React from 'react';
import { ExternalLink, Globe, Building, TrendingUp, Briefcase, BookOpen, Shield } from 'lucide-react';

const linkCategories = [
  {
    title: 'News Sources',
    icon: Globe,
    links: [
      { name: 'BBC News', url: 'https://bbc.com/news', description: 'Global news coverage' },
      { name: 'Reuters', url: 'https://reuters.com', description: 'Breaking news & analysis' },
      { name: 'Associated Press', url: 'https://apnews.com', description: 'Independent journalism' },
      { name: 'NPR', url: 'https://npr.org', description: 'Public radio news' },
    ]
  },
  {
    title: 'Business & Finance',
    icon: TrendingUp,
    links: [
      { name: 'Bloomberg', url: 'https://bloomberg.com', description: 'Financial markets' },
      { name: 'Wall Street Journal', url: 'https://wsj.com', description: 'Business news' },
      { name: 'Financial Times', url: 'https://ft.com', description: 'Global finance' },
      { name: 'MarketWatch', url: 'https://marketwatch.com', description: 'Stock market news' },
    ]
  },
  {
    title: 'Technology',
    icon: Briefcase,
    links: [
      { name: 'TechCrunch', url: 'https://techcrunch.com', description: 'Startup & tech news' },
      { name: 'Ars Technica', url: 'https://arstechnica.com', description: 'Tech analysis' },
      { name: 'Wired', url: 'https://wired.com', description: 'Future technology' },
      { name: 'The Verge', url: 'https://theverge.com', description: 'Tech culture' },
    ]
  },
  {
    title: 'Research & Analysis',
    icon: BookOpen,
    links: [
      { name: 'Pew Research', url: 'https://pewresearch.org', description: 'Social trends data' },
      { name: 'Brookings', url: 'https://brookings.edu', description: 'Policy research' },
      { name: 'Council on Foreign Relations', url: 'https://cfr.org', description: 'Global affairs' },
      { name: 'World Economic Forum', url: 'https://weforum.org', description: 'Economic insights' },
    ]
  }
];

export const UsefulLinks: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <ExternalLink className="h-5 w-5 text-primary-600" />
        <h2 className="text-lg font-semibold text-gray-900">Useful Links</h2>
      </div>
      
      <div className="space-y-6">
        {linkCategories.map((category) => {
          const Icon = category.icon;
          return (
            <div key={category.title}>
              <div className="flex items-center space-x-2 mb-3">
                <Icon className="h-4 w-4 text-gray-600" />
                <h3 className="font-medium text-gray-900 text-sm">{category.title}</h3>
              </div>
              <div className="space-y-2 ml-6">
                {category.links.map((link) => (
                  <a
                    key={link.name}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block group"
                  >
                    <div className="flex items-start justify-between p-2 rounded-md hover:bg-gray-50 transition-colors">
                      <div className="flex-1">
                        <div className="text-sm font-medium text-primary-600 group-hover:text-primary-700">
                          {link.name}
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {link.description}
                        </div>
                      </div>
                      <ExternalLink className="h-3 w-3 text-gray-400 group-hover:text-gray-600 mt-1 flex-shrink-0" />
                    </div>
                  </a>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};